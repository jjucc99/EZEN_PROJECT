package kr.co.ezenac.item.model.vo;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CategoryVO {
	private int cate_code;
	private String cate_name;
}
