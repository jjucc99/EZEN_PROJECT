package kr.co.ezenac.item.model.vo;


public class CategoryVO {
	private int cate_code;
	private String cate_name;
}
