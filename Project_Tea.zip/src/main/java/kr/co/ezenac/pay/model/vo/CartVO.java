package kr.co.ezenac.pay.model.vo;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CartVO {
	private int cart_no;
	private String mem_id;
}
