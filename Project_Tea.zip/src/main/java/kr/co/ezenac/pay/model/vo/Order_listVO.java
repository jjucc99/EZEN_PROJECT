package kr.co.ezenac.pay.model.vo;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Order_listVO {
	private int ord_no;
	private String ord_date;
	private String ord_reciever;
	private String ord_addr1;
	private String ord_addr2;
	private String ord_addr3;
	private String ord_phone;
	private String delivery_status;
	private String ord_status;
	private String mem_id;
	private int pay_no;
}
