package kr.co.ezenac.pay.model.dao;

import org.springframework.stereotype.Repository;

@Repository("pDAO")
//implement와 연결할 아이디
public class PayDAO {

}
