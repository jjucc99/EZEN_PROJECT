package kr.co.ezenac.pay.model.service;

public interface PayService {

}
