package kr.co.ezenac.pay.model.vo;


public class PayVO {
	private int pay_no;
	private String pay_method;
	private String pay_date;
}
