package kr.co.ezenac.pay.model.vo;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PayVO {
	private int pay_no;
	private String pay_method;
	private String pay_date;
}
