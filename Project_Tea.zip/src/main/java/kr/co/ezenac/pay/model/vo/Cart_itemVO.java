package kr.co.ezenac.pay.model.vo;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Cart_itemVO {
	private int cart_item_no;
	private int cart_amount;
	private int cart_no;
	private int item_code;
}
