package kr.co.ezenac.admin.model.vo;


public class ItemVO {
	private int item_code;
	private String item_name;
	private int item_price;
	private String item_information;
	private int cate_code;
}
