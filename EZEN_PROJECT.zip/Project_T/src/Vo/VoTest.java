package Vo;

public class VoTest {

}
