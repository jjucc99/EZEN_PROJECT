package kr.co.ezenac.pay.model.vo.none;


public class Order_itemVO {
	private int ord_item_no;
	private int count;
	private int item_code;
	private int ord_no;
}
