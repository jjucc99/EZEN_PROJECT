package kr.co.ezenac.image.model.vo;

public class ImagesVO {
	private int ord_item_no;
	private String img_name;
	private String img_save;
	private String img_ref;
	private String img_id;
	
}
