package kr.co.ezenac.board.model.vo;

public class ReplyVO {
	private int reply_no;
	private String reply_sub;
	private String reply_content;
	private String reply_date;
	private String reply_board;
	private int board_no;
}
