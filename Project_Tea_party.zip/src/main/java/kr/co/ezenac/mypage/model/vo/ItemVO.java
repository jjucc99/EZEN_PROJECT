package kr.co.ezenac.mypage.model.vo;

public class ItemVO {
	private int item_code;
	private String item_name;
	private int item_price;
	private String item_information;
	private int cate_code;
}
