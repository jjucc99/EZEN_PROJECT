package kr.co.ezenac.admin.model.vo;

public class Item_mgmVO {
	private int prod_code;
	private String inout_date;
	private int prod_count;
	private int item_code;
	
}
