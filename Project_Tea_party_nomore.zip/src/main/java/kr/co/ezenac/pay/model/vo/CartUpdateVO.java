package kr.co.ezenac.pay.model.vo;

public class CartUpdateVO {
private int cart_amount;
private int cart_item_no;

public int getCart_amount() {
	return cart_amount;
}
public void setCart_amount(int cart_amount) {
	this.cart_amount = cart_amount;
}
public int getCart_item_no() {
	return cart_item_no;
}
public void setCart_item_no(int cart_item_no) {
	this.cart_item_no = cart_item_no;
}

}
