package kr.co.ezenac.pay.model.vo;

public class SubOrderVO {
String str;
int num;
public String getStr() {
	return str;
}
public void setStr(String str) {
	this.str = str;
}
public int getNum() {
	return num;
}
public void setNum(int number) {
	this.num = number;
}
}
